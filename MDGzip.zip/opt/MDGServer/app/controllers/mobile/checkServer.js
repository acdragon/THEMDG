exports.checkServer = function (req, res) {
    res.send(200, 'NdgServer');
};
